﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMS.Web.Infrastructure.Enumerations
{
    public enum ProductSorting
    {
        PriceAscending = 1,
        PriceDescending = 2,
        CountAscening = 3,
        CountDescening = 4
    }
}
