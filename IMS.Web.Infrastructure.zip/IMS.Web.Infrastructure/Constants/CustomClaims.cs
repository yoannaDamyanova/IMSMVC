﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMS.Web.Infrastructure.Constants
{
    public static class CustomClaims
    {
        public const string UserFullNameClaim = "user:fullname";
    }
}
